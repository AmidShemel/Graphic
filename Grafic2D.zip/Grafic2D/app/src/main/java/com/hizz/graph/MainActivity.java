package com.hizz.graph;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button bt;
    TextView tv;
    private Drawing mDrawing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Draw2D draw2D = new Draw2D(this);
        //setContentView(draw2D);

        //Grafic grapf = new Grafic(this);
        //drawing = new Drawing(this);
        mDrawing = (Drawing) findViewById(R.id.drawing);

        //setContentView(grapf);
        //setContentView(drawing);

        bt = (Button) findViewById(R.id.button1);
        //tv = (TextView) findViewById(R.id.textView1);


        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*tv.setText("Hello!!");
                drawing.radius = 150;*/
                mDrawing.swapColor();
            }
        });




    }
}
