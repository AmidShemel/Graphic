package com.hizz.graph;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;

/**
 * Created by Dima on 20.11.2017.
 */

public class Draw2D extends View {

    private Paint mPaint = new Paint();
    private Rect mRect = new Rect();

    public Draw2D(Context context) {
        super(context);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        mPaint.setStyle(Paint.Style.FILL);
        mPaint.setColor(Color.BLUE);
        canvas.drawPaint(mPaint);

        mPaint.setAntiAlias(true);
        mPaint.setColor(Color.YELLOW);
        canvas.drawCircle(800, 200, 120, mPaint);

        mPaint.setColor(Color.GREEN);
        canvas.drawRect(0, 1500, 1080, 1920, mPaint);

        mPaint.setColor(Color.MAGENTA);
        mPaint.setStyle(Paint.Style.FILL);
        mPaint.setAntiAlias(true);
        mPaint.setTextSize(92);
        canvas.drawText("Blue color", 60, 900, mPaint);

        int x = 800, y = 200;
        String luch = "лучик солнца лучик солнца лучик солнца";
        mPaint.setColor(Color.YELLOW);
        mPaint.setTextSize(22);
        mPaint.setStyle(Paint.Style.FILL);

        canvas.rotate(10, x + mRect.exactCenterX(), y + mRect.exactCenterY());
        canvas.drawText(luch, x, y, mPaint);

        canvas.rotate(45, x + mRect.exactCenterX(), y + mRect.exactCenterY());
        canvas.drawText(luch, x, y, mPaint);

        canvas.rotate(90, x + mRect.exactCenterX(), y + mRect.exactCenterY());
        canvas.drawText(luch, x, y, mPaint);

        canvas.rotate(135, x + mRect.exactCenterX(), y + mRect.exactCenterY());
        canvas.drawText(luch, x, y, mPaint);

        canvas.rotate(180, x + mRect.exactCenterX(), y + mRect.exactCenterY());
        canvas.drawText(luch, x, y, mPaint);

        canvas.rotate(225, x + mRect.exactCenterX(), y + mRect.exactCenterY());
        canvas.drawText(luch, x, y, mPaint);

        canvas.rotate(270, x + mRect.exactCenterX(), y + mRect.exactCenterY());
        canvas.drawText(luch, x, y, mPaint);

        canvas.rotate(310, x + mRect.exactCenterX(), y + mRect.exactCenterY());
        canvas.drawText(luch, x, y, mPaint);


        canvas.restore();


    }
}
