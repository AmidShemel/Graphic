package com.hizz.graph;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.os.Build;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * Created by Dima on 12.12.2017.
 */

public class Drawing extends View implements View.OnClickListener {

    private Paint mPaint, mPaintBackground, mPaintText;
    private Paint mCirclePaint;
    private Paint mLinesPaint;
    private Path triangle;
    private Path path;
    int width, height;
    int radius = 250;
    private float mCircleX, mCircleY, mCircleX1, mCircleY1, mCircleX2, mCircleY2;
    private  float mCircleR1 = 10f;
    PointF point;

    public Drawing(Context context) {
        this(context, null);
        init (null);
    }

    public Drawing(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
        init (attrs);
    }

    public Drawing(Context context, AttributeSet attrs, int defStyleAttr) {
        this(context, attrs, defStyleAttr, 0);
        init (attrs);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public Drawing(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        //you can also init your attributes here (if you have any)

        init (attrs);
    }

    private void init (@Nullable AttributeSet set){
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mCirclePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mLinesPaint = new Paint();
        mPaintBackground = new Paint();
        mPaintText = new Paint();
        triangle = new Path();
        path = new Path();
        point = new PointF (getWidth()/2f, getHeight()/2f);
        //point = new PointF (500, 1000);
        mCirclePaint.setColor(Color.GRAY);
        mPaintText .setColor(Color.DKGRAY);
        mPaintBackground.setColor(Color.GRAY);

    }

    public void swapColor(){
        mCirclePaint.setColor(mCirclePaint.getColor() == Color.GRAY ? Color.DKGRAY : Color.GRAY);
        mPaintBackground.setColor(mPaintBackground.getColor() == Color.GRAY ? Color.DKGRAY : Color.GRAY);
        mPaintText.setColor(mPaintText.getColor() == Color.DKGRAY ? Color.GRAY : Color.DKGRAY);
        invalidate();
    }

    @Override
    public void onDraw(Canvas canvas) {

        mLinesPaint.setColor(Color.WHITE);
        drawAngLines(canvas);
        mLinesPaint.reset();


        width = getWidth();
        height = getHeight();
        String w = Integer.toString(width);
        String h = Integer.toString(height);
        canvas.drawRect(0, 0, width, height, mPaintBackground);
        canvas.drawCircle(width/2, height/2, radius, mCirclePaint);
        mPaintText.setTextSize(30);
        canvas.drawText(w+"x"+h, 50, 50, mPaintText);



/*
        // очистка path
        triangle.reset();

        // угол
        triangle.moveTo(100, 100);
        triangle.lineTo(150, 250);
        triangle.lineTo(50, 200);

        // треугольник
        triangle.moveTo(250, 100);
        triangle.lineTo(300, 200);
        triangle.lineTo(200, 200);
        triangle.close();

        //triangle.addRect(rectf, Path.Direction.CW);
        triangle.addCircle(450, 150, 25, Path.Direction.CW);

        // рисование path
        mPaint.setColor(Color.BLACK);
        mPaint.setStrokeWidth(2);
        mPaint.setStyle(Paint.Style.STROKE);
        canvas.drawPath(triangle, mPaint);
        mPaint.reset();
       */ // Трикутник


//        mPaint.setStrokeWidth(3);
//        mPaint.setColor(Color.YELLOW);
//        canvas.drawLine(100, getHeight()/3, getWidth() - 100, getHeight()/3, mPaint);
//        mPaint.reset();


        if (mCircleX == 0f || mCircleY == 0f){
            mCircleX = getWidth()/2;
            mCircleY = getHeight()/3 + 333;
        }
        if(mCircleX1 == 0f || mCircleY1 == 0f){
            mCircleX1 = getWidth()/2 - 250;
            mCircleY1 = getHeight()/3 + 100;
        }
        if(mCircleX2 == 0f || mCircleY2 == 0f){
            mCircleX2 = getWidth()/2 + 250;
            mCircleY2 = getHeight()/3 - 100;
        }

        // Три точки
        mPaint.reset();
        mPaint.setStyle(Paint.Style.FILL);
        mPaint.setStrokeWidth(5);
        mPaint.setColor(Color.GREEN);
        canvas.drawCircle(mCircleX, mCircleY, mCircleR1, mPaint);
        mPaint.setColor(Color.RED);
        canvas.drawCircle(mCircleX1, mCircleY1, mCircleR1, mPaint);
        canvas.drawCircle(mCircleX2, mCircleY2, mCircleR1, mPaint);
        mPaint.reset();

        float p1x = 200f;
        float p2x = getWidth() - 200f;
        float p1y = getHeight() / 3f;

/*
        path.moveTo(100, getHeight()/3);
        //path.quadTo(point.x, point.y, p2x, p2y);
        path.quadTo(mCircleX, mCircleY, p2x, p2y);
        mPaint.setStyle(Paint.Style.STROKE);
        canvas.drawPath(path, mPaint);
        path.reset();
        mPaint.reset();

        path.moveTo(100, getHeight()/3);
        path.cubicTo(mCircleX1, mCircleY1, mCircleX2, mCircleY2, p2x, p2y);
        mPaint.setStyle(Paint.Style.STROKE);
        canvas.drawPath(path, mPaint);

        path.reset();
        mPaint.reset();
*/  // Старые кривые безье

        mPaint.reset();
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setColor(Color.GREEN);
        mPaint.setStrokeWidth(2);
        path.moveTo(p2x, p1y);
        path.quadTo(mCircleX, mCircleY, p1x, p1y);
        path.cubicTo(mCircleX1, mCircleY1, mCircleX2, mCircleY2, p2x, p1y);
        canvas.drawPath(path, mPaint);

        mLinesPaint.setColor(Color.YELLOW);
        canvas.clipPath(path);
        drawAngLines(canvas);

        path.reset();
        mPaint.reset();

/*        path.moveTo(250,250);
        path.addCircle(250, 250, 150, Path.Direction.CW);
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setColor(Color.BLUE);
        mPaint.setStrokeWidth(2);
        canvas.drawPath(path, mPaint);

        mLinesPaint.setColor(Color.YELLOW);
        //canvas.translate(500, 900);
        canvas.clipPath(path);
        drawAngLines(canvas);


        path.addCircle(800, 250, 100, Path.Direction.CW);
        canvas.drawPath(path, mPaint);
        canvas.translate(0, 900);
        canvas.clipPath(path);
        drawAngLines(canvas);


        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setColor(Color.BLUE);
        mPaint.setStrokeWidth(2);
        canvas.drawCircle(250, 250, 50, mPaint);
        */ //Старые круглые клипПатчи

    }

    //создание косых линий
    public void drawAngLines (Canvas canvas){
        for(int i = 0; i < getHeight() + getWidth(); i=i+25){
            canvas.drawLine(-getHeight() + i, 0, 0 + i, getHeight(), mLinesPaint);
        }
    }

    //обработка нажатий
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        boolean value = super.onTouchEvent(event);

        switch (event.getAction()){
            case MotionEvent.ACTION_DOWN:{
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                float x = event.getX();
                float y = event.getY();
                float x1 = event.getX();
                float y1 = event.getY();
                float x2 = event.getX();
                float y2 = event.getY();

                double dx = Math.pow(x - mCircleX, 2);
                double dy = Math.pow(y - mCircleY, 2);
                double dx1 = Math.pow(x1 - mCircleX1, 2);
                double dy1 = Math.pow(y1 - mCircleY1, 2);
                double dx2 = Math.pow(x2 - mCircleX2, 2);
                double dy2 = Math.pow(y2 - mCircleY2, 2);

                if (dx + dy < Math.pow(mCircleR1 + 100, 2)){
                //if (Math.pow(dx + dy, 0.5) < mCircleR){
                    mCircleX = x;
                    mCircleY = y;
                    invalidate();
                    return true;
                }
                if (dx1 + dy1 < Math.pow(mCircleR1 + 100, 2)){
                    //if (Math.pow(dx + dy, 0.5) < mCircleR){
                    mCircleX1 = x1;
                    mCircleY1 = y1;
                    invalidate();
                    return true;
                }
                if (dx2 + dy2 < Math.pow(mCircleR1 + 100, 2)){
                    //if (Math.pow(dx + dy, 0.5) < mCircleR){
                    mCircleX2 = x2;
                    mCircleY2 = y2;
                    invalidate();
                    return true;
                }
                return value;
            }
        }

        return value;
    }

    @Override
    public void onClick(View v) {

    }
}
