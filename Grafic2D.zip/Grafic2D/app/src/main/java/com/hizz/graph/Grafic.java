package com.hizz.graph;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.Log;
import android.view.View;

import java.util.Arrays;


public class Grafic extends View {

    private Paint mPaint = new Paint();
    private Paint mPaint2 = new Paint();
    private Rect mRect = new Rect();
    static int daysInMonth = 31;
    static int[] bals = new int[daysInMonth];
    static int bMax, bMin;
    static double bMid1;// bMid2;

    public Grafic(Context context) {
        super(context);
        Bals();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);


        String outBals = Arrays.toString(bals);
        Log.d("Bals", outBals);

        float[] verticalLines = new float[daysInMonth * 4];
        String text;
        int x, y, width = canvas.getWidth();
        int xLeft = 100, yUp = 0, yDown = 150;
        int yStep = 60, xStep = (width - xLeft) / daysInMonth;
        int height = yStep * 12 + yDown;

        //mPaint.setColor(Color.WHITE);
        canvas.drawPaint(mPaint);

        mPaint.setColor(Color.DKGRAY);
        canvas.drawRect(0, 0, width, height, mPaint);
        mPaint.setColor(Color.LTGRAY);
        canvas.drawCircle(width/2, height/2, 150, mPaint);

/*
//Розмітка
        mPaint.setColor(Color.LTGRAY);
        float[] horizontalLines = { xLeft, yUp += yStep, x = xStep * daysInMonth + xLeft - xStep, yUp,
                xLeft, yUp += yStep, x, yUp,
                xLeft, yUp += yStep, x, yUp,
                xLeft, yUp += yStep, x, yUp,
                xLeft, yUp += yStep, x, yUp,
                xLeft, yUp += yStep, x, yUp,
                xLeft, yUp += yStep, x, yUp,
                xLeft, yUp += yStep, x, yUp,
                xLeft, yUp += yStep, x, yUp,
                xLeft, yUp += yStep, x, yUp,
                xLeft, yUp += yStep, x, yUp,
                xLeft, yUp += yStep, x, yUp};
        yUp = 0;

        for(int i = 0; i < daysInMonth * 4; i++){
            if (i == 0) {
                verticalLines[i] = xLeft;
                i++;
                verticalLines[i] = yUp += yStep;
                i++;
            } else {
                verticalLines[i] = xLeft += xStep;
                i++;
                verticalLines[i] = yUp;
                i++;
            }
            verticalLines[i] = xLeft;
            i++;
            verticalLines[i] = height - yDown;
        }
        canvas.drawLines(horizontalLines, mPaint);
        canvas.drawLines(verticalLines, mPaint);

//надпис "бал"
        text = "Бал";
        x = 5;
        y = height / 2;
        mPaint.setColor(Color.GREEN);
        mPaint.setStyle(Paint.Style.FILL);
        mPaint.setTextAlign(Paint.Align.CENTER);
        mPaint.setAntiAlias(true);
        mPaint.setTextSize(40);
        canvas.rotate(90, x + mRect.exactCenterX(), y + mRect.exactCenterY());
        canvas.drawText(text, x, y, mPaint);
        canvas.rotate(-90, x + mRect.exactCenterX(), y + mRect.exactCenterY());

        int xTm = 150;
        int yTm = height - yDown + 100;
        text = "Max: " + bMax;
        canvas.drawText(text, xTm, yTm, mPaint);
        xTm += width / 3;
        text = "Min: " + bMin;
        canvas.drawText(text, xTm, yTm, mPaint);
        xTm += width / 3;
        text = "Mid: " + bMid1; // + ", " + bMid2;
        canvas.drawText(text, xTm, yTm, mPaint);



//бали (оцінка успішності)
        int y2 = height - yDown + yStep + 10;
        xLeft = 100;
        mPaint.setColor(Color.YELLOW);
        mPaint.setStyle(Paint.Style.FILL);
        mPaint.setTextAlign(Paint.Align.RIGHT);
        mPaint.setAntiAlias(true);
        mPaint.setTextSize(28);

        for(int i = 1; i < 13; i++){
            text = Integer.toString(i);
            canvas.drawText(text, xLeft - 20, y2 -= yStep, mPaint);
        }

//Число місяця
        x = 100;
        y = height + 40 - yDown;
        int count;
        mPaint.setColor(Color.YELLOW);
        mPaint.setStyle(Paint.Style.FILL);
        mPaint.setTextAlign(Paint.Align.CENTER);
        mPaint.setAntiAlias(true);
        mPaint.setTextSize(28);

        if (width > 1080){
            count = 1;
        } else count = 2;

        for(int i = 2; i <= daysInMonth; i+=count){
            text = Integer.toString(i);
            Log.d("dates", text);
            canvas.drawText(text, x += xStep, y, mPaint);
            if(count == 2) x += xStep;
        }
        mPaint.reset();


//Шкала
        //mPaint2.setColor(getResources().getColor(R.color.PINK));
        mPaint2.setColor(getResources().getColor(R.color.LIGHT_ORANGE));
        //float[] redLines = {520,200,520,400};
        mPaint2.setStrokeWidth(6);
       // canvas.drawLines(redLines, mPaint2);

//Крапки
*//*
        mPaint.setColor(getResources().getColor(R.color.LIGHT_GREEN ));
        float[] greenPoints = {300,200, 350,200,400,200,450,200,500,200};
        mPaint.setStrokeWidth(7);
        canvas.drawPoints(greenPoints, mPaint);
        mPaint.reset();
*//*

//Круг
        mPaint.reset();
        mPaint.setColor(getResources().getColor(R.color.LIGHT_GREEN ));
        int rad = 10;
        int pX = 100;
        int pY;
        float lX1 = 100, lY1 = height - yDown, lX2 = 100, lY2 = 0;
        for (int i = 0; i < bals.length; i++){
            int bal = bals[i];
            if(i < 1){
                pX = 100;
                //lY1 -= yStep * bal - yStep;
            } else {
                pX += xStep;
                lX2 = pX;
            }
            if (bal == 0) continue;
            pY = height - yDown;
            //lY1 = yStep * bal - yStep;
            switch (bal){
                case 1:
                    //pY = height - yDown;
                    break;
                case 2:
                    pY -= yStep * bal - yStep;
                    break;
                case 3:
                    pY -= yStep * bal - yStep;
                    break;
                case 4:
                    pY -= yStep * bal - yStep;
                    break;
                case 5:
                    pY -= yStep * bal - yStep;
                    break;
                case 6:
                    pY -= yStep * bal - yStep;
                    break;
                case 7:
                    pY -= yStep * bal - yStep;
                    break;
                case 8:
                    pY -= yStep * bal - yStep;
                    break;
                case 9:
                    pY -= yStep * bal - yStep;
                    break;
                case 10:
                    pY -= yStep * bal - yStep;
                    break;
                case 11:
                    pY -= yStep * bal - yStep;
                    break;
                case 12:
                    pY -= yStep * bal - yStep;
                    break;
                default:
                    //lY1 = height - yDown + pY;
                    break;
            }
            canvas.drawCircle(pX, pY, rad, mPaint);
            lY2 = pY;
            if (i == 0) lY1 = pY;
            //lY1 = pY;
            canvas.drawLine(lX1, lY1, lX2, lY2, mPaint2);
            lX1 = pX;
            lY1 = pY;
        }
        canvas.drawLine(lX1, lY1, x, lY2, mPaint2);

        mPaint.reset();
*/

    }
//Генерація оцінок
    public static void Bals(){
        for(int i = 0; i < daysInMonth; i++) {
            int r = (int) (Math.random() * 25 - 12);
            if (r >= 1) {
                bals[i] = r;
            } else {
                bals[i] = 0;
            }
        }
        int max = 0, min = 12, mid = 0, j = 0;

        for (int i = 0; i < daysInMonth; i++){
            if (bals[i] > max) max = bals[i];
            if (bals[i] < min) {
                if(bals[i] !=0) min = bals[i];
            }
            if(bals[i] != 0) {
                mid += bals[i];
                j++;
            }
        }
        bMid1 = (double) mid / (double) j;
        //bMid2 = j;
        bMax = max;
        bMin = min;
    }
}